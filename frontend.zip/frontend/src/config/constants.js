const baseUrl = "http://62.72.29.187:4500";

export { baseUrl };
