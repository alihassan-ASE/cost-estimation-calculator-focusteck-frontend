const baseUrl = "http://localhost:4500";

export { baseUrl };
