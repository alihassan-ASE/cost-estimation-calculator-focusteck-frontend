import React from "react";
import { Box, Typography } from "@mui/material";

import StaffComponent from "../Components/StaffComponent";

const page = () => {
  return (
    <Box>
      <StaffComponent />
    </Box>
  );
};

export default page;
